const WebSocket = require ('ws');
const wss = new WebSocket.Server({port : 3000});

wss.on('connection', (ws) => {
    console.log('client connected');

    // kakakaak
    setInterval( () => {
        ws.send(JSON.stringify({massage : 'Data dari server',
            timestamp: new Date ()
        }));
    },3000);

    //kjwdwdhw 
    ws.on('close', ()=>{
        console.log('client dissconnected');
    });
});
console.log('Websocet server berjalan di wa://localhost:3000')